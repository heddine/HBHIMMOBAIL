# 📱 GestiBail — Publication Play Store
## Guide complet : PWA → Google Play Store

---

## 📁 Structure des fichiers à déployer

```
votre-site/
├── index.html          ← fichier principal (modifié)
├── manifest.json       ← manifest PWA externe
├── sw.js               ← service worker
├── icons/
│   ├── icon-48x48.png
│   ├── icon-72x72.png
│   ├── icon-96x96.png
│   ├── icon-128x128.png
│   ├── icon-144x144.png
│   ├── icon-152x152.png
│   ├── icon-192x192.png
│   ├── icon-256x256.png
│   ├── icon-384x384.png
│   └── icon-512x512.png
├── screenshots/        ← À CRÉER (voir ci-dessous)
│   ├── screen1.png     ← 1080×1920px
│   └── screen2.png     ← 1080×1920px
└── .well-known/
    └── assetlinks.json ← À COMPLÉTER après PWABuilder
```

---

## 🚀 ÉTAPES DANS L'ORDRE

### ÉTAPE 1 — Déployer les fichiers
Uploadez TOUS les fichiers ci-dessus sur votre hébergement (GitHub Pages ou Netlify).

⚠️ **Important** : le domaine doit être **HTTPS** (GitHub Pages et Netlify sont OK).

**Pour GitHub Pages :**
```
git add .
git commit -m "feat: ajout manifest, sw, icones pour Play Store"
git push
```

---

### ÉTAPE 2 — Vérifier la PWA

Ouvrez Chrome sur Android, naviguez vers votre site.  
Vérifiez dans Chrome DevTools > Application > Manifest que tout est vert.

Ou testez en ligne : https://web.dev/measure/

✅ Critères obligatoires :
- Manifest.json valide
- Service Worker actif
- HTTPS
- Icônes 192×192 et 512×512

---

### ÉTAPE 3 — Créer les screenshots (OBLIGATOIRE Play Store)

Prenez 2-8 captures d'écran de l'app sur mobile :
- Taille : **1080×1920 px** (format portrait)
- Format : PNG ou JPEG
- Nommez-les `screen1.png`, `screen2.png`, etc.
- Uploadez-les dans le dossier `/screenshots/`

---

### ÉTAPE 4 — Générer l'APK avec PWABuilder

1. Allez sur **https://www.pwabuilder.com**
2. Entrez l'URL de votre site (ex: `https://votre-domaine.com`)
3. Cliquez **Start** → attendez l'analyse
4. Cliquez **Package for stores** → **Android**
5. Configurez :
   - **Package ID** : `com.hbh.gestibail`
   - **App version** : `1.0`
   - **Version code** : `1`
   - **Display mode** : `standalone`
   - Laissez **Signing** sur "Generate new" (première fois)
6. Cliquez **Generate** → téléchargez le ZIP

Le ZIP contient :
- `app-release-bundle.aab` → à uploader sur Play Store
- `signing.keystore` → **GARDEZ CE FICHIER PRÉCIEUSEMENT !**
- `signing-key-info.txt` → contient le SHA-256 fingerprint

---

### ÉTAPE 5 — Configurer assetlinks.json

Après avoir généré l'APK, ouvrez `signing-key-info.txt` et copiez le **SHA-256 fingerprint**.

Modifiez `.well-known/assetlinks.json` :
```json
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.hbh.gestibail",
    "sha256_cert_fingerprints": [
      "AA:BB:CC:DD:EE:FF:..."  ← REMPLACEZ PAR VOTRE SHA-256
    ]
  }
}]
```

Puis redéployez sur votre hébergement.

---

### ÉTAPE 6 — Publier sur Google Play Console

1. Créez un compte **Google Play Console** (25 USD une fois)
   → https://play.google.com/console

2. Créez une nouvelle application :
   - Nom : `GestiBail`
   - Langue : Français
   - Application / Application gratuite

3. Remplissez la **fiche Play Store** :
   - Titre : `GestiBail — Gestion de Baux`
   - Description courte (max 80 car.) : `Contrats de bail, états des lieux, quittances professionnelles`
   - Description longue : (voir ci-dessous)
   - Screenshots : uploadez vos captures
   - Icône haute résolution : `icon-512x512.png`
   - Image de bannière : 1024×500 px (à créer)

4. **Uploadez le fichier AAB** :
   - Production > Créer une version
   - Uploadez `app-release-bundle.aab`

5. **Politique de confidentialité** (OBLIGATOIRE) :
   Créez une page simple expliquant que l'app stocke les données localement sur l'appareil.
   URL exemple : `https://votre-domaine.com/privacy.html`

---

## 📝 Description longue suggérée pour le Play Store

```
GestiBail est l'application professionnelle de gestion de baux immobiliers, 
conçue pour les propriétaires et gestionnaires de biens en France.

✅ FONCTIONNALITÉS PRINCIPALES
• Génération de contrats de bail (vide, meublé, commercial, rural)
• États des lieux d'entrée et de sortie avec photos
• Quittances de loyer mensuelles
• Signatures tactiles bailleur et locataire
• Calcul automatique du prorata loyer
• Inventaire du mobilier
• Clauses personnalisables

💾 STOCKAGE LOCAL
Toutes vos données restent sur votre appareil — aucune inscription, 
aucun serveur, aucun abonnement.

📱 OFFLINE FIRST
L'application fonctionne sans connexion internet après le premier chargement.

🔒 CONFIDENTIALITÉ
Vos données ne quittent jamais votre appareil.
```

---

## ⚠️ POINTS D'ATTENTION

| Problème courant | Solution |
|---|---|
| "App non installable" | Vérifier HTTPS + manifest.json valide |
| Icône floue sur Play | Utiliser icon-512x512.png (PNG, pas SVG) |
| Barre d'adresse visible dans l'app | `display: standalone` dans manifest |
| App plante au lancement | Vérifier assetlinks.json déployé sur HTTPS |
| Rejet Play Store | Ajouter page politique de confidentialité |

---

## 📞 Ressources utiles

- PWABuilder : https://www.pwabuilder.com
- Play Console : https://play.google.com/console  
- Test Lighthouse : https://web.dev/measure/
- Vérif assetlinks : https://digitalassetlinks.googleapis.com/v1/statements:list?source.web.site=https://VOTRE-DOMAINE
